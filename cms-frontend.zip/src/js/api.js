// src/js/api.js
let API_BASE = "http://localhost:5000"; // fallback dla dev

// 1) Jawne ładowanie configu – zwraca Promise
export async function loadConfig() {
  try {
    const res = await fetch("/config/config.json", { cache: "no-store" });
    if (res.ok) {
      const cfg = await res.json();
      if (cfg?.API_BASE) {
        API_BASE = cfg.API_BASE;
      }
    }
  } catch (e) {
    console.warn("Nie udało się wczytać config.json – używam fallback:", API_BASE);
  }
  console.log("API_BASE =", API_BASE);
  return API_BASE;
}

// (opcjonalnie do testów/override)
export function setApiBase(url) {
  API_BASE = url;
  console.log("setApiBase ->", API_BASE);
}

export function getApiBase() {
  return API_BASE;
}

// --- Helpery HTTP ---
export async function api(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    ...options,
  });

  let data = null;
  try { data = await res.json(); } catch {}

  if (res.status === 401 || res.status === 403) {
    const next = encodeURIComponent(location.pathname + location.search);
    if (!location.pathname.endsWith("/login.html")) {
      location.href = `/login.html?next=${next}`;
    }
    throw new Error(data?.message || "Wymagane zalogowanie");
  }
  if (!res.ok) {
    throw new Error(data?.message || `Błąd ${res.status}`);
  }
  return data;
}

export async function apiWithStatus(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  let data = null;
  try { data = await res.json(); } catch {}
  return { status: res.status, ok: res.ok, data };
}

export async function getProfile() {
  const { status, data } = await apiWithStatus("/api/users/profile");
  return status === 200 ? data : null;
}
